ForgeFit 1.2 — Strength + Cardio / Equipment Update

What changed
- Separate Strength and Cardio time selection. The total shown is the full planned workout.
- A 30-minute plan now builds enough activities to fill the selected strength/cardio blocks instead of collapsing to one exercise.
- Workout preview before Start, with Strength and Cardio clearly separated.
- Coach and Full Plan use the same generated workout; Coach guides one exercise at a time, Full Plan shows all exercises.
- Editable Equipment Available Today controls; choices save locally and do not require another download.
- Editable Home and Apartment Gym equipment profiles in Settings.
- Visual exercise guide cards plus written step-by-step instructions.
- Separate Strength vs Cardio alternative exercise selection.
- Explanation button for each exercise: focus, secondary muscles, why it was selected, instructions, and cues.
- Resistance-band sets record band color (Yellow / Green / Red) rather than showing 0 lb.
- Skip an exercise for today without penalty.
- Too Easy / Too Hard can adjust the next unfinished set when appropriate.
- Planned time remaining is shown during a workout.
- Finish Early saves the workout as partial instead of discarding the work.
- Existing readiness, recovery, history, progress, movement logging, exercise preferences, and position rules are preserved.

Install / update on iPhone
1. Keep this entire folder together after unzipping.
2. Open index.html through the same Safari/PWA hosting method you used for the current ForgeFit build.
3. Add to Home Screen if needed.
4. Equipment and workout preferences are stored locally in Safari once selected.

Note: band colors are intentionally recorded by color only because resistance colors are not standardized between manufacturers.
